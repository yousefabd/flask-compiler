package python.semantic.unit_tests;

import errors.ErrorReporter;
import python.PythonFrontend;
import python.models.root.Program;
import python.semantic.PythonSemanticResult;
import python.symbol_table.Scope;
import python.symbol_table.SymbolKind;

import java.nio.file.Path;
import java.util.Set;
import java.util.stream.Collectors;

public final class PythonImportAliasSemanticTest {
    public static void main(String[] args) {
        Path source = Path.of("tests", "python", "semantic", "import_aliases.py");
        ErrorReporter reporter = new ErrorReporter();
        PythonFrontend frontend = new PythonFrontend(source, reporter);
        Program program = frontend.parsePython();
        require(program != null, "Import-alias fixture did not parse: " + reporter.formatReport());

        PythonSemanticResult result = frontend.analyzePython(program);
        require(!result.hasErrors(), "Valid import aliases received diagnostics: "
                + result.diagnostics());

        Scope module = result.symbolTable().getModuleScope();
        requireImport(module, "path_alias", 1);
        requireImport(module, "WebApp", 2);
        requireImport(module, "render_template", 3);
        require(module.resolveLocal("os") == null,
                "Aliased dotted import incorrectly bound its first path component");
        require(module.resolveLocal("Flask") == null,
                "Aliased from-import incorrectly bound the original imported name");
        require(module.resolveLocal("path") == null,
                "Dotted import incorrectly bound its final path component");

        Set<String> usedImports = result.identifierBindings().values().stream()
                .filter(symbol -> symbol.getKind() == SymbolKind.IMPORT)
                .map(symbol -> symbol.getName())
                .collect(Collectors.toSet());
        require(usedImports.equals(Set.of("path_alias", "WebApp", "render_template")),
                "Alias reads did not bind to imported symbols: " + usedImports);

        System.out.println("Python import-alias semantics passed.");
    }

    private static void requireImport(Scope scope, String name, int line) {
        var symbol = scope.resolveLocal(name);
        require(symbol != null, "Missing imported binding " + name);
        require(symbol.getKind() == SymbolKind.IMPORT,
                name + " was not recorded as an import");
        require(symbol.getDeclarationLine() == line,
                name + " has the wrong declaration line: " + symbol.getDeclarationLine());
    }

    private static void require(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}

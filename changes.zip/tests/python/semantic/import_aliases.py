import os.path as path_alias
from flask import Flask as WebApp
from flask import render_template

path_value = path_alias
factory = WebApp
renderer = render_template

rebound_alias = 1
import package as rebound_alias
rebound_result = rebound_alias()

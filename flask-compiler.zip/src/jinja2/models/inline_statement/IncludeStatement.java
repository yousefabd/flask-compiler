package jinja2.models.inline_statement;

import jinja2.models.TemplateNode;
//import jinja2.models.expression.Expression;

import java.util.ArrayList;
import java.util.List;
//
//public class IncludeStatement extends InlineStatement
//{
//    public Expression template;
//
//
//    public IncludeStatement(Expression templateExpression, int lineNumber)
//    {
//        super("IncludeStatement", lineNumber);
//        this.template = templateExpression;
//    }
//
//    @Override
//    public String toString() {
//        return "Template: ";
//    }
//
//    @Override
//    public List<TemplateNode> getChildren() {
//        List<TemplateNode> children = new ArrayList<>();
//        if (template != null) children.add(template);
//        return children;
//    }
//}
